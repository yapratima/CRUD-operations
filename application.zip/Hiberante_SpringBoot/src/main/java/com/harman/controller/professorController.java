package com.harman.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.harman.model.Professor;
import com.harman.service.professorService;

@Controller
public class professorController {
	@Autowired
	professorService profservice;

	@RequestMapping("/")
	public String home(Model m) {
		m.addAttribute("command", new Professor());
		return "index";
	}

	@RequestMapping("/empform")
	public String showform(Model m) {
		m.addAttribute("command", new Professor());
		return "empform";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(@ModelAttribute("prof") Professor prof) {
		profservice.save(prof);
		return "redirect:/viewemp";
	}

	@RequestMapping("/viewemp")
	public String viewemp(Model m) {
		List<Professor> list = profservice.getAllProfessors();
		m.addAttribute("list", list);
		return "viewemp";
	}

	@RequestMapping(value = "/editemp/{id}")
	public String edit(@PathVariable int id, Model m) {
		Professor prof = profservice.getProfessorById(id);
		m.addAttribute("command", prof);
		return "empeditform";
	}

	@RequestMapping(value = "/editemp/editsave", method = RequestMethod.POST)
	public String editsave(@ModelAttribute("emp") Professor prof) {
		profservice.updateProfessor(prof);
		return "redirect:/viewemp";
	}

	@RequestMapping(value = "/deleteemp/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable int id) {
		profservice.deleteProfessor(id);
		return "redirect:/viewemp";
	}

	@RequestMapping("/search")
	public String search(Model m) {
		m.addAttribute("command", new Professor());
		return "search";
	}

	
	@RequestMapping("/searchByName")
	public String searchByName(Model m) {
		m.addAttribute("command", new Professor());
		return "searchByName";
	}
	 
	@RequestMapping("/searchByDesg")
	public String searchByDesg(Model m) {
		m.addAttribute("command", new Professor());
		return "searchByDesg";
	}

	@RequestMapping(value = "/searchById", method = RequestMethod.POST)
	public String search(@RequestParam("id") int id, Model m) {
		Professor emp = profservice.getProfessorById(id);
		if (emp == null) {
			String er = "Not Found";
			m.addAttribute("message", er);
			return "error";
		}
		m.addAttribute("emp", emp);
		return "viewempbyid";

	}

	@RequestMapping(value = "/searchByName", method = RequestMethod.POST)
	public String searchByName(@RequestParam("name") String name, Model m) {
		List<Professor> list = profservice.searchByName(name);
		m.addAttribute("list", list);
		return "viewemp";

	}

	@RequestMapping(value = "/searchByDesg", method = RequestMethod.POST)
	public String searchByDesig(@RequestParam("profDesignation") String desig, Model m) {
		List<Professor> list = profservice.searchByDesg(desig);
		m.addAttribute("list", list);
		return "viewemp";

	}

}
