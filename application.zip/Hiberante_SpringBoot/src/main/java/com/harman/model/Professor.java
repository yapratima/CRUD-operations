package com.harman.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="professor")
@Table(name="professorboot")
public class Professor {
	
	@Id
	private int id;
	@Column
	private String name;
	@Column
	private String profDesignation;
	@Column
	private float salary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProfDesignation() {
		return profDesignation;
	}
	public void setProfDesignation(String profDesignation) {
		this.profDesignation = profDesignation;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	

}
