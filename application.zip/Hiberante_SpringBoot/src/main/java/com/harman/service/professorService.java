package com.harman.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.harman.Dao.professorDao;
import com.harman.model.Professor;



@Service
public class professorService {
	
	@Autowired
	 professorDao profDao;
	
	public List<Professor> getAllProfessors(){
		return profDao.getAllProfessors();
	}
	
	public Professor getProfessorById(int id) {
		return profDao.getProfessorByID(id);
	}
	
	public void updateProfessor(Professor prof) {
		 profDao.updateProfessor(prof);
	}
	
	public void deleteProfessor(int id) {
		profDao.deleteProfessor( id);
	}

	public  void save(Professor prof) {
		profDao.save(prof);
	}
	
	public List<Professor> searchByName(String name) {
		return profDao.searchByName(name);
		
	}

	

	public List<Professor> searchByDesg(String desig) {
		return profDao.searchByDesg(desig);
	}
}
