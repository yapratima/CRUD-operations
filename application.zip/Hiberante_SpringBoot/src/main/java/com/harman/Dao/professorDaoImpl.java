package com.harman.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.harman.model.Professor;

@Repository
public class professorDaoImpl implements professorDao{
	
	
	@Autowired
	protected SessionFactory sessionFactory;
	

	public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
 }

	 protected Session getSession(){
         return sessionFactory.openSession();
  }

	@Override
	public List<Professor> getAllProfessors() {
		Session session=getSession();
		String sql="from professor";
		Query query=session.createQuery(sql);
		List acc=query.list();
		return acc;
	}

	@Override
	public Professor getProfessorByID(int id) {
		Session session=getSession();
		Professor prof=(Professor) session.get(Professor.class, id);
		session.close();
		
		return prof;
	}

	@Override
	public void updateProfessor(Professor prof) {
		Session session=getSession();
		session.update(prof);
		session.beginTransaction().commit();
		session.close();
		
	}

	@Override
	public void deleteProfessor(int id) {
		Session session=getSession();
		Professor prof=(Professor) session.get(Professor.class, id);
		session.delete(prof);
		session.beginTransaction().commit();
		session.close();
		
	}

	@Override
	public void save(Professor prof) {
		Session session=getSession();
		session.save(prof);
		session.beginTransaction().commit();
		session.close();
		
		
	}

	@Override
	public List<Professor> searchByName(String name) {
		Session session=getSession();
		String sql="from professor where name like '"+name+"%'";
		Query query=session.createQuery(sql);
		List<Professor> result=query.list();
		System.out.println("The result is:"+result);
		
		return result;
	}

	@Override
	public List<Professor> searchByDesg(String desig) {
		Session session=getSession();
		String sql="from professor where profDesignation like '"+desig+"%'";
		Query query=session.createQuery(sql);
		List<Professor> desigresult=query.list();
		System.out.println("The result is:"+desigresult);
		
		return desigresult;
	}

}
