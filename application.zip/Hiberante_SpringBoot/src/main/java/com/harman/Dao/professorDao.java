package com.harman.Dao;

import java.util.List;
import com.harman.model.Professor;

public interface professorDao {

	public List<Professor> getAllProfessors();

	public Professor getProfessorByID(int id);

	public void updateProfessor(Professor prof);
	public void deleteProfessor(int id);
	
	public void save(Professor prof);

	public List<Professor> searchByName(String name);

	public List<Professor> searchByDesg(String desig);

}
