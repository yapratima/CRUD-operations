package com.harman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HiberanteSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(HiberanteSpringBootApplication.class, args);
	}

}
